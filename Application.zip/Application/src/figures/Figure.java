package figures;

/**
 * Created by user on 02.06.2017.
 */
public abstract class Figure {
    private int b;

    public abstract double getSquare();
}
