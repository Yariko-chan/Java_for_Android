package bankomat;

/**
 * Created by user on 07.06.2017.
 */
public class Windows implements OnBankomatListener {
    @Override
    public void onGetMoney(int sum) {

    }

    @Override
    public void onGetMoney(boolean isOk) {

    }
}
