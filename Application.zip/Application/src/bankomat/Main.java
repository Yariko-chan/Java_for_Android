package bankomat;

/**
 * Created by user on 07.06.2017.
 */
public class Main {
    public static void main(String[] args) {
        UI ui = new UI();
        ui.startUI();
    }

}
