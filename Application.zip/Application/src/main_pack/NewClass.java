package main_pack;

import java.util.Scanner;

public class NewClass {

    public static void main (String[] args) {
        StringBuilder sb = new StringBuilder();

    }
}