package main_pack;

/**
 * Created by user on 29.05.2017.
 */
public class FirstClass {
    public static int a = 6;
    public int b = 7;

    public static void publicM() {}

    protected static void protectedMethod() {}

    private static void privateMethod() {}

    static void method() {

    }
}
