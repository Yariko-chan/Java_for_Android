package interfaces;

/**
 * Created by user on 05.06.2017.
 */
public interface OnToggleListener {

    public void onClick();
}
