package cars;

/**
 * Created by user on 02.06.2017.
 */
public class BlueCar extends Car {
    private static final int COLOR = 0;

    public BlueCar() {
    }

    @Override
    public int getColor() {
        return COLOR;
    }
}
