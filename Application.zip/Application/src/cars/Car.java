package cars;

/**
 * Created by user on 02.06.2017.
 */
public abstract class Car {
    public abstract int getColor();
}
