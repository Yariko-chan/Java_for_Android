package patterns.singletone;

/**
 * Created by user on 21.06.2017.
 */
public class View {
    public static void main(String[] args) {
        Controller controller = Controller.getInstance();
    }
}
