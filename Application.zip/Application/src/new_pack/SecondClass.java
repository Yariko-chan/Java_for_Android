package new_pack;

import main_pack.FirstClass;

/**
 * Created by user on 29.05.2017.
 */
public class SecondClass {
    public static void someMethod() {
        FirstClass.publicM();
//        FirstClass.protectedMethod();
//        FirstClass.method();
    }
}
